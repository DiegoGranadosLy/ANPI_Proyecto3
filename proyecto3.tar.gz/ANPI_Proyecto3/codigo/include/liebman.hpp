
#ifndef LIEBMAN_HPP
#define LIEBMAN_HPP

#include <curses.h>
#include <math.h>
#include <omp.h>
#include <vector>


using namespace std;

struct message{
		vector<float> pUp;
		vector<float> pDown;
		vector<float> pLeft;
		vector<float> pRight;
		int horizontal;
		int vertical;
		int sizeSquare;
	};

namespace liebman{
	const float acceptable = 0.001;
	const int iterations = 25;

	float cal_error(float &_a, float &_b);
	void Liebmann(message _s,float *matrix);
} // namespace LIEBMAN

#include <liebman.cpp>

#endif
